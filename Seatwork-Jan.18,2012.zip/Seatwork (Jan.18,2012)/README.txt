Instructions:

1. Create a function that accepts a two dimensional array and it's size (using pointer notation). Populate and display the 20 arrays.

2. Write a program that uses a vector object to store a set of integer numbers. Then create a function that will return the smallest largest and average of the numbers in the vector.

Sir,  yan po yung seatwork namin last wednesday. Yung sa 1 po yung PointerNotation.cpp, and yung sa 2 po yung Vector.cpp. May error po sir, hindi ko po maayos sir eh. Medyo naguguluhan pa din po ako sa pointer, nagpaturo lang po ako sa kaklase ko.. 